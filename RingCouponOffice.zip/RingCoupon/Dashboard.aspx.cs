﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RingCoupon
{
    public partial class Dashboard : System.Web.UI.Page
    {
        public static DataTable dtCouponData = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dtCouponData = Utility.csConfig.GetCouponData();
                RepterCouponData.DataSource = dtCouponData;
                RepterCouponData.DataBind();
            }
        }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            string FileName = "COUPON_DATA_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dtCouponData, "COUPON_DATA");

                Response.Clear();
                Response.Buffer = true;
                Response.Charset = "";
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("content-disposition", "attachment;filename=" + FileName);
                using (MemoryStream MyMemoryStream = new MemoryStream())
                {
                    wb.SaveAs(MyMemoryStream);
                    MyMemoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                }
            }

        }
    }
}