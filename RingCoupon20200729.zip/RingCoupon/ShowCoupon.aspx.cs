﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RingCoupon
{
    public partial class ShowCoupon : System.Web.UI.Page
    {
        public string htmlPath = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HTML_PATH"]);
        public void CreateCouponVoucher(string CouponCode, string ValidFrom, string ValidTo)
        {
            try
            {
                string FileName = "Ring_Voucher_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".pdf";

                string htmltext = System.IO.File.ReadAllText(Server.MapPath(htmlPath));
                htmltext = htmltext.Replace("@@PROMOCODE@@", CouponCode);
                htmltext = htmltext.Replace("@@VALID TILL@@", CouponCode);
                htmltext = htmltext.Replace("@@VALID AT@@", CouponCode);


                StringReader sr = new StringReader(htmltext);
                Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, memoryStream);
                    pdfDoc.Open();

                    htmlparser.Parse(sr);
                    pdfDoc.Close();

                    byte[] bytes = memoryStream.ToArray();
                    memoryStream.Close();

                    Response.Clear();
                    Response.ContentType = "application/pdf";
                    Response.AddHeader("Content-Disposition", "attachment; filename=" + FileName);
                    Response.Buffer = true;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.BinaryWrite(bytes);
                    Response.End();
                    Response.Close();
                }
            }
            catch
            {
                string msg = "Error while downloading file, Please save your coupon code to redeem future.";
                Page page = HttpContext.Current.Handler as Page;
                ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + msg + "');", true);
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if (Request.QueryString["cc"] != null)
                {
                    lblPromoCode.Value = Convert.ToString(Request.QueryString["cc"]);                    
                    lblFrom.Value = System.DateTime.Now.ToString("dd/MM/yyyy");
                    lblTo.Value = System.DateTime.Now.AddDays(14).ToString("dd/MM/yyyy");
                }
            }
        }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                string FileName = "Ring_Voucher_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".pdf";

                Response.ContentType = "application/pdf";
                Response.AddHeader("content-disposition", "attachment;filename=" + FileName);
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                this.Page.RenderControl(hw);
                StringReader sr = new StringReader(sw.ToString());
                Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
                HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                pdfDoc.Open();
                htmlparser.Parse(sr);
                pdfDoc.Close();
                Response.Write(pdfDoc);
                Response.End();
            }
            catch
            {
                string msg = "Error while downloading file, Please save your coupon code to redeem future.";
                Page page = HttpContext.Current.Handler as Page;
                ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + msg + "');", true);
            }
        }

        protected void btnExport2_Click(object sender, EventArgs e)
        {
            CreateCouponVoucher(lblPromoCode.Value, lblFrom.Value, lblTo.Value);
        }
    }
}