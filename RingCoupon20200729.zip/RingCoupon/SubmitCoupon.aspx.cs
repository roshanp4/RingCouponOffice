﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls; 

namespace RingCoupon
{
    public partial class SubmitCoupon : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                //CreateCouponVoucher("","","");
                lblfinalmsg.Visible = false;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string msg = string.Empty;
            string Result = string.Empty;
            Result = Utility.csConfig.InsertCouponData(txtFullName.Value,txtMobile.Value,txtEmail.Value,ddlBranch.Value);

            if (Result == "1")
            {
                
                txtFullName.Value = "";
                txtMobile.Value = "";
                txtEmail.Value = "";

                if (ddlBranch.Value == "Arabian Ranges")
                {
                    ddlBranch.SelectedIndex = 0;
                    lblfinalmsg.Visible = true;
                    OpenPDF("Ring Leaflet Roadshow Voucher 01.pdf");
                }
                else if (ddlBranch.Value == "Spring Souq")
                {
                    ddlBranch.SelectedIndex = 0;
                    lblfinalmsg.Visible = true;
                    OpenPDF("Ring Leaflet Roadshow Voucher 02.pdf");
                }
                else
                {
                    msg = "Invalid Mall selection. Please try again.";
                    Page page = HttpContext.Current.Handler as Page;
                    ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + msg + "');", true);
                    return;
                }
            }
            else
            {
                msg = "Failed to generate voucher, Please try again.";
                Page page1 = HttpContext.Current.Handler as Page;
                ScriptManager.RegisterStartupScript(page1, page1.GetType(), "err_msg", "alert('" + msg + "');", true);
            }
            
        }

        public void OpenPDF(string FileName)
        {
            string Name = "Ring_Voucher_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".pdf";

            Response.ContentType = "Application/pdf";
            Response.AppendHeader("Content-Disposition", "attachment; filename="+ Name);
            Response.TransmitFile(Server.MapPath("~/Files/"+ FileName));
            Response.End();
        }
        public void CreateCouponVoucher(string CouponCode, string ValidFrom, string ValidTo)
        {
            string FileName = "Ring_Voucher_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".pdf";

            string htmltext = System.IO.File.ReadAllText(Server.MapPath("indexB.html"));
            htmltext = htmltext.Replace("@@PROMOCODE@@", CouponCode);
            htmltext = htmltext.Replace("@@VALID TILL@@", CouponCode);
            htmltext = htmltext.Replace("@@VALID AT@@", CouponCode);


            StringReader sr = new StringReader(htmltext);
            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            using (MemoryStream memoryStream = new MemoryStream())
            {
                PdfWriter writer = PdfWriter.GetInstance(pdfDoc, memoryStream);
                pdfDoc.Open();

                htmlparser.Parse(sr);
                pdfDoc.Close();

                byte[] bytes = memoryStream.ToArray();
                memoryStream.Close();

                Response.Clear();
                Response.ContentType = "application/pdf";
                Response.AddHeader("Content-Disposition", "attachment; filename=" + FileName);
                Response.Buffer = true;
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.BinaryWrite(bytes);
                Response.End();
                Response.Close();
            }


        }
    }
}