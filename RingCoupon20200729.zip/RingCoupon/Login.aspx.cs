﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RingCoupon
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            bool Islogin = false;
            Islogin = Utility.csConfig.RCLogin(txtEMail.Value, txtPassword.Value);
            if(Islogin)
            {
                Response.Redirect("Dashboard.aspx");
            }
            else
            {
                string msg = "Login failed, Please try again";
                Page page = HttpContext.Current.Handler as Page;
                ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + msg + "');", true);
            }
        }
    }
}